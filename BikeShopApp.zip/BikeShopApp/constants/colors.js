const Colors = {
        accent500: "#87C1ff",
        primary300: "#C8A2C9",
        primary500: "#29021A",
        primary800: "#8b008b",

};

export default Colors;

